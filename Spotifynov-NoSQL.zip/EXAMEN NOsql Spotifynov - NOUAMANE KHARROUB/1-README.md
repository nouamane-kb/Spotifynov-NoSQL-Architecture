# SpotifYnov - Plateforme de Streaming Musical Next-Gen

## 1. Vue d'ensemble de l'architecture (Polyglot Persistence)

Ce projet repose sur une architecture de type "Polyglot Persistence", utilisant quatre bases de données NoSQL distinctes pour tirer parti des forces spécifiques de chaque technologie.

### Schéma de l'Architecture

Le backend central communique avec 4 pôles de données :

[Application Backend]
      |
      +--- MongoDB (Document) : Catalogue (Artistes, Albums)
      |
      +--- Cassandra (Wide-Column) : Historique d'écoute et Logs
      |
      +--- Redis (Clé-Valeur) : Sessions utilisateurs et Cache
      |
      +--- Neo4j (Graphe) : Réseau social et Recommandations

### Rôle de chaque base de données

* Redis : Sert de "porte d'entrée" pour vérifier l'identité (Sessions) et servir les données fréquentes avec une latence inférieure à la milliseconde.
* MongoDB : Stocke la complexité du catalogue musical (biographies, métadonnées variées, structures imbriquées).
* Neo4j : Gère les relations complexes entre utilisateurs (système d'amis) et le moteur de recommandation.
* Cassandra : Conçu pour enregistrer le flux massif et continu des logs d'écoute (Time-Series).

---

## 2. Justification des Choix Techniques

### MongoDB (Catalogue Musical)
* Pourquoi : Les données artistiques sont hétérogènes. Un groupe possède des membres, un artiste solo non ; les albums ont des structures variées.
* Avantages : Le modèle Document (JSON/BSON) permet d'imbriquer les pistes directement dans l'objet Album, évitant des jointures coûteuses pour l'affichage.
* Réalisations : Schéma avec validation, indexation textuelle et pipelines d'agrégation (Lookup).

### Redis (Cache & Sessions)
* Pourquoi : Nécessité d'une réponse immédiate pour la validation des connexions et l'affichage des tops titres.
* Avantages : Stockage en mémoire RAM. Les opérations atomiques (INCR, LPUSH) permettent de gérer des compteurs en temps réel sans conflits d'écriture.
* Réalisations : Gestion de session avec expiration (TTL), pattern Cache-Aside et files d'attente.

### Neo4j (Social & Recommandations)
* Pourquoi : Les bases relationnelles (SQL) sont inefficaces pour parcourir des réseaux d'amis profonds (trop de jointures).
* Avantages : Le langage Cypher permet de traverser le graphe pour trouver des amis d'amis ou des recommandations par similarité très rapidement.
* Réalisations : Modélisation du graphe social, calcul de similarité (Jaccard) et détection de communautés.

### Cassandra (Historique d'écoute)
* Pourquoi : Une plateforme de streaming génère des millions d'écritures par seconde.
* Choix architectural : Base optimisée pour l'écriture (Write-Heavy) et la scalabilité horizontale.

---

## 3. Instructions d'Installation et d'Exécution

### Prérequis
* MongoDB Shell (mongosh) ou Compass
* Python 3.12+ (avec librairie 'redis')
* Neo4j Desktop
* Redis Server (local)

### A. Exécution MongoDB (Catalogue)
Dans un terminal ou via Mongosh, exécutez les scripts dans cet ordre pour initialiser la base :
1. mongodb/mongodb_schema.js (Création des collections et validateurs)
2. mongodb/mongodb_insert.js (Insertion des données de test)
3. mongodb/mongodb_indexes.js (Création des index de performance)
4. mongodb/mongodb_queries.js (Tests des opérations CRUD)
5. mongodb/mongodb_aggregations.js (Tests des agrégations analytiques)

### B. Exécution Neo4j (Social)
1. Lancer la base "spotifynov" dans Neo4j Desktop.
2. Ouvrir Neo4j Browser.
3. Copier et exécuter le contenu de neo4j/neo4j_schema.cypher (Contraintes).
4. Copier et exécuter le contenu de neo4j/neo4j_insert.cypher (Génération des données).
5. Exécuter les requêtes de neo4j/neo4j_queries.cypher pour tester les recommandations.

### C. Exécution Redis (Cache)
Assurez-vous que le serveur Redis est lancé, puis exécutez le script de test global :
python redis/redis_test.py

---

## 4. Difficultés Rencontrées et Solutions

### Le défi Cassandra (Environnement Windows)
* Problème : L'installation native de Cassandra sur Windows s'est révélée instable (conflits de dépendances Python 2.7 et variables d'environnement), empêchant le démarrage des nœuds.
* Solution adoptée : Pour cet examen, la priorité a été donnée à l'implémentation complète et fonctionnelle des trois autres bases (MongoDB, Redis, Neo4j) qui démontrent l'architecture NoSQL.
* Perspective : Dans un environnement de production, l'utilisation de Docker (conteneurisation) serait la solution standard pour isoler Cassandra du système d'exploitation hôte.

### La génération de données Neo4j
* Défi : Créer un jeu de données suffisamment dense pour que les algorithmes de recommandation fonctionnent (avoir assez de relations communes).
* Solution : Développement d'un script Cypher utilisant des boucles (UNWIND) et des fonctions aléatoires (rand) pour générer automatiquement plus de 200 relations et garantir la pertinence des tests.

### Connexion Redis
* Problème : Erreur de connexion (ConnectionRefused) lors des premiers tests.
* Solution : Compréhension de l'architecture Client-Serveur nécessitant deux terminaux distincts (un pour le moteur, un pour le script Python).

---
Auteur : NOUAMANE KHARROUB
Date : 02/02/2026